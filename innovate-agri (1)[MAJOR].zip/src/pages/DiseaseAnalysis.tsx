import React, { useState } from 'react';
import * as tf from '@tensorflow/tfjs';
import { DISEASE_CLASSES } from '../utils/model-utils';

const DiseaseAnalysis = () => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [prediction, setPrediction] = useState<string>('');
  const [confidence, setConfidence] = useState<number | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) setSelectedImage(file);
  };

  const predictDisease = async () => {
    if (!selectedImage) return;

    const img = new Image();
    img.src = URL.createObjectURL(selectedImage);
    img.onload = async () => {
      const tensor = tf.browser.fromPixels(img).resizeNearestNeighbor([224, 224]).toFloat().expandDims(0);
      const model = await tf.loadLayersModel('/model/model.json');
      const predictions = model.predict(tensor) as tf.Tensor;
      const values = await predictions.data();
      const maxVal = Math.max(...values);
      const index = values.indexOf(maxVal);
      setPrediction(DISEASE_CLASSES[index]);
      setConfidence(parseFloat((maxVal * 100).toFixed(2)));
    };
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-md max-w-xl mx-auto">
      <input type="file" accept="image/*" onChange={handleImageChange} className="mb-4" />
      <button
        onClick={predictDisease}
        className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
      >
        Predict Disease
      </button>

      {prediction && (
        <div className="mt-4 text-center">
          <p className="text-xl">Prediction: <strong>{prediction}</strong></p>
          <p>Confidence: {confidence}%</p>
        </div>
      )}
    </div>
  );
};

export default DiseaseAnalysis;
