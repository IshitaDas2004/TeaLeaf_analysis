import React from 'react';
import DiseaseAnalysis from './pages/DiseaseAnalysis';

const App = () => {
  return (
    <div className="min-h-screen bg-green-50 p-4">
      <h1 className="text-3xl font-bold text-center text-green-800 mb-6">InnovateAgri - Disease Detection</h1>
      <DiseaseAnalysis />
    </div>
  );
};

export default App;
