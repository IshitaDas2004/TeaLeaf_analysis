export const DISEASE_CLASSES = [
  'Anthracnose',
  'Brown Blight',
  'Gray Blight',
  'Red Leaf Spot',
  'Algal Leaf Spot',
  'Bird Eye Spot',
  'White Spot',
  'Healthy'
];
